import { Component, OnInit } from '@angular/core';
import { PointageService } from '../Service/pointage-service.service';
import { Pointage } from '../models/pointage.model';

@Component({
  selector: 'app-pointage',
  templateUrl: './pointage.component.html',
  styleUrls: ['./pointage.component.css']
})
export class PointageComponent implements OnInit {
  pointages: Pointage[] = [];
  filteredPointages: Pointage[] = [];
  pagedPointages: Pointage[] = [];
  currentPage: number = 1;
  itemsPerPage: number = 10;
  totalPages: number = 0;
  searchQuery: string = '';
  showForm: boolean = false;
  currentTab: string = 'infos'; 
  toastMessage: string | null = null;
  toastType: string | null = null;
  pointage: Pointage = {
    id: 0,
    nom: '',
    date: '',
    heureDebut: '',
    heureFin: '',
    commentaire: ''
  };

  constructor(private pointageService: PointageService) { }

  ngOnInit(): void { 
    // Chargement des pointages lors de l'initialisation du composant
    this.loadPointages();
  }

  // Méthode pour charger les pointages depuis le service
  loadPointages(): void {
    this.pointageService.getPointages().subscribe((data) => {
      console.log('Pointages chargés:', data); // Debugging
      this.pointages = data;
      this.filteredPointages = data;
      this.updatePagination();
    });
  }

  // Méthode pour afficher ou masquer le formulaire de pointage
  toggleForm(): void {
    this.showForm = !this.showForm;
    if (!this.showForm) {
      // Réinitialiser le formulaire lorsque le formulaire est masqué
      this.pointage = {
        id: 0,
        nom: '',
        date: '',
        heureDebut: '',
        heureFin: '',
        commentaire: ''
      };
    }
  }

  // Méthode pour changer d'onglet
  changeTab(tabName: string): void {
    this.currentTab = tabName;
  }

  // Méthode pour soumettre le formulaire (création ou mise à jour d'un pointage)
  onSubmit(): void {
    console.log('Soumission du formulaire:', this.pointage); // Debugging

    if (this.pointage.id !== 0) {
      // Mise à jour d'un pointage existant
      this.pointageService.updatePointage(this.pointage.id, this.pointage).subscribe(() => {
        this.showToast('Pointage mis à jour avec succès', 'success');
        this.loadPointages(); // Recharger les pointages
        this.toggleForm();
      });
    } else {
      // Création d'un nouveau pointage
      this.pointageService.createPointage(this.pointage).subscribe(() => {
        this.showToast('Pointage ajouté avec succès', 'success');
        this.loadPointages(); // Recharger les pointages
        this.toggleForm();
      });
    }
  }

  // Méthode pour pré-remplir le formulaire avec les données d'un pointage existant
  editPointage(id: number): void {
    this.pointageService.getPointageById(id).subscribe((data) => {
      console.log('Pointage à modifier:', data); // Debugging
      this.pointage = data;
      this.toggleForm();
    });
  }

  // Méthode pour confirmer la suppression d'un pointage
  confirmDelete(id: number): void {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce pointage ?')) {
      this.pointageService.deletePointage(id).subscribe(() => {
        this.showToast('Pointage supprimé avec succès', 'success');
        this.loadPointages(); // Recharger les pointages
      });
    }
  }

  // Méthode pour filtrer les pointages selon la recherche
  filterPointages(): void {
    this.filteredPointages = this.pointages.filter(pointage =>
      pointage.nom.toLowerCase().includes(this.searchQuery.toLowerCase())
    );
    this.updatePagination();
  }

  // Méthode pour mettre à jour les informations de pagination
  updatePagination(): void {
    this.totalPages = Math.ceil(this.filteredPointages.length / this.itemsPerPage);
    this.goToPage(this.currentPage);
  }

  // Méthode pour naviguer vers une page spécifique
  goToPage(page: number): void {
    this.currentPage = page;
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.pagedPointages = this.filteredPointages.slice(startIndex, endIndex);
  }

  // Méthode pour calculer le nombre d'heures travaillées
  calculateHoursWorked(pointage: Pointage): number {
    const start = new Date(`1970-01-01T${pointage.heureDebut}:00`);
    const end = new Date(`1970-01-01T${pointage.heureFin}:00`);
    const diff = end.getTime() - start.getTime();
    return diff / (1000 * 60 * 60); // Conversion en heures
  }

  // Méthode pour calculer les heures supplémentaires
  calculateOvertimeHours(pointage: Pointage): number {
    const hoursWorked = this.calculateHoursWorked(pointage);
    return hoursWorked > 8 ? hoursWorked - 8 : 0;
  }

  // Méthode pour afficher un message de toast
  showToast(message: string, type: string): void {
    this.toastMessage = message;
    this.toastType = type;
    setTimeout(() => this.toastMessage = null, 3000); // Masquer le toast après 3 secondes
  }
}
