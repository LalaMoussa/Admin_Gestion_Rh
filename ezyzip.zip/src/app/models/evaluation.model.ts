import { Projet } from "./projet.model";
import { Technicien } from "./technicien.model";

export interface Evaluation {
    id: number;
    qualite: string;
    delai: string;
    cooperation: string;
    commentaire: string;
    scoreTotal: number;
    dateEvaluation?: Date;
    formation: string;
    projet?: Projet[];
    technicien?: Technicien; // Modifié ici pour correspondre au type attendu
}
