export interface Tache {
  nom: string;
  responsable: string;
  dateDebut: string;
  dateFin: string;
  statut: string;
  commentaire?: string;
  
}
